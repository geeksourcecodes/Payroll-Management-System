<?php

?>

<?php

if(isset($_POST['submit'])!="")
{
    $name      = $_POST['name'];
    $c_type   = $_POST['c_type'];
    $address      = $_POST['address'];
    $mobile     = $_POST['mobile'];
    
    $details      = $_POST['details'];

    $sql = $conn->query("INSERT into company(name,company_type,address, mobile, delete_status, details)VALUES('$name','$c_type','$address','$mobile', '0', '$details')");

    if($sql)
    {
        ?>
        <script>
            alert('Company had been successfully added.');
            window.location.href='home_company.php?page=company_list';
        </script>
        <?php
    }

    else
    {
        ?>
        <script>
            alert('Invalid.');
            window.location.href='index.php';
        </script>
        <?php
    }
}
?>
