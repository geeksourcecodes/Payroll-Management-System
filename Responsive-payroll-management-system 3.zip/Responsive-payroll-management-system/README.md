# Responsive payroll management system
Full project is in the Zip file named Payroll.zip
Just download the Zip file and SQL file
Database informations will be find in the db.php
if username or password needed.. username: admin password: admin
