

<?php
include("first.php");
include("add_company.php");



?>
<?php
include("php/headerCompany.php");
?>
        <div id="page-wrapper">
            <div id="page-inner">


<div class="row">
    <div class="col-md-12">
        <h1 class="page-head-line">Company</h1>
        
            <style type="text/css">
               .different-text-color { color: green; }
            </style>

        <marquee> <h1 class="page-subhead-line"><p style="font-size:x-large;"><span class="different-text-color">WELCOME TO--COMPANY @<strong><?php echo ' '. $siteName ?></strong>@@@Today is:
        <i class="icon-calendar icon-large" ></i>


        <?php
        date_default_timezone_set("Asia/Dhaka");
        echo  date(" l, F d, Y") . "<br>";

        ?>
        </span></p> </h1> </marquee>

    </div>
</div>

    <div class="well bs-component">
        <form class="form-horizontal">
            <fieldset>
                <button type="button" data-toggle="modal" data-target="#addCompany" class="btn btn-success">Add New Company</button>
                <p align="center"><big><b>List of Companies</b></big></p>
                <div class="table-responsive">
                    <form method="post" action="" >

                        <table class="table table-bordered table-hover table-condensed" id="myTable">
                            <!-- <h3><b>Ordinance</b></h3> -->
                            <thead>
                            <tr class="info">
                                <th><p align="center">Name/Number</p></th>
                                <th><p align="center">Company_type</p></th>
                                <th><p align="center">Address</p></th>
                                <th><p align="center">details</p></th>
                                <th><p align="center">Action</p></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php




                            $query = "SELECT * from company WHERE delete_status ='0'";
                            global $id,$deleting_id;
                            $q = $conn->query($query);
                            while($row = $q->fetch_assoc())
                            {
                                $id     =$row['id'];
                                $name  =$row['name'];
                                $c_type   =$row['company_type'];
                                $number  =$row['mobile'];
                                $address  =$row['address'];
                                $details   =$row['details'];
                                
                                

                                ?>

                                <tr id="<?php echo $row["id"] ?>">
                                   <input name="id" type="hidden" value="<?php  echo $id?>" />
                                    <td align="center"><a href="view_company.php?id=<?php echo $row["id"]; ?>" title="Update"><?php echo $row['name'] ?></br><?php echo $row['mobile'] ?></a></td>
                                     <td align="center"><a href="view_company.php?id=<?php echo $row["id"]; ?>" title="Update"><?php echo $c_type;?></a></td>
                                    <td align="center"><a href="view_company.php?id=<?php echo $row["id"]; ?>" title="Update"><?php echo $row['address'] ?></a></td>
                                    <td align="center"><a href="view_company.php?id=<?php echo $row["id"]; ?>" title="Update"><?php echo $row['details'] ?></a></td>
                                    <td align="center" width="200">
                                        <a class="btn btn-primary" href="view_groupList.php?id=<?php echo $row["id"]; ?>" title="List of company groups"><em class="fas fa-list-ul"></em></a>
                                        <button class="btn btn-danger btn remove"><em class="fas fa-trash"></em></button>
                                        <!--
                                        <button type="button" data-toggle="modal" data-target="#deleteCompany" class="btn btn-danger btn-sm remove"><em class="fas fa-trash"></em></button>
                                        -->
                                    </td>
                                </tr>

                            <?php } ?>
                            </tbody>

                            <tr class="info">
                                <th><p align="center">Name/Number</p></th>
                                <th><p align="center">Company Type</p></th>
                                <th><p align="center">Address</p></th>
                                <th><p align="center">details</p></th>
                                <th><p align="center">Action</p></th>
                            </tr>
                        </table>
                    </form>
                </div>
            </fieldset>
        </form>
    </div>

    <!-- this modal is for ADDING an Company -->
    <div class="modal fade" id="addCompany" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header" style="padding:20px 50px;">
                    <button type="button" class="close" data-dismiss="modal" title="Close">&times;</button>
                    <h3 align="center"><b>Add Company</b></h3>
                </div>
                <div class="modal-body" style="padding:40px 50px;">

                    <form class="form-horizontal" action="#" name="form" method="post">
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Company Name</label>
                            <div class="col-sm-8">
                                <input type="text" name="name" class="form-control" placeholder="Company name" required="required">
                            </div>
                        </div>
                        <div class="form-group">
                  <label class="col-sm-4 control-label">Company Type</label>
                  <div class="col-sm-8">
                    <select name="c_type" class="form-control" placeholder="Company Type" required>
                      <option value="">Company Type</option>
                      <option value="Regular">Regular</option>
                      <option value="Casual">Casual</option>
                    </select>
                  </div>
                </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Address</label>
                            <div class="col-sm-8">
                                <input type="textarea" rows="4" cols="50" name="address" class="form-control" placeholder="Address" required="required">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Mobile</label>
                            <div class="col-sm-8">
                                <input type="text" name="mobile" class="form-control" placeholder="Enter Mobile No." >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Details</label>
                            <div class="col-sm-8">
                                <input type="textarea" rows="4" cols="30" name="details" class="form-control" placeholder="Company Details" required="required">
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="col-sm-4 control-label"></label>
                            <div class="col-sm-8">
                                <input type="submit" name="submit" class="btn btn-success" value="Submit">
                                <input type="reset" name="" class="btn btn-danger" value="Clear Fields">
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

<!-- this modal is for DELETING COMPANY -->
    <div class="modal fade" id="deleteCompany" role="dialog">
        <div class="modal-dialog">
            
            

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header" style="padding:20px 50px;">
                    <button type="button" class="close" data-dismiss="modal" title="Close">&times;</button>
                    <h3 align="center"><b>Delete Company</b></h3>
                </div>
                <div class="modal-body" style="padding:40px 50px;">

                    <form class="form-horizontal" action="deletecompany.php" name="form" method="post">
                        
                       
                     <div class="alert alert-danger"><span class="glyphicon glyphicon-warning-sign"></span> Are you sure you want to delete this Record?</div>

                        <div class="form-group">
                            <label class="col-sm-4 control-label"></label>
                            <div class="col-sm-4">
                                
                                <button type="submit" name ="submit" class="btn btn-success" ><span class="glyphicon glyphicon-ok-sign"></span>Yes</button>
                                
                                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span>No</button>
                            </div>
                            
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>


    <!-- this modal is for my Colins -->
    <div class="modal fade" id="colins" role="dialog">
        <div class="modal-dialog modal-sm">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header" style="padding:20px 50px;">
                    <button type="button" class="close" data-dismiss="modal" title="Close">&times;</button>
                    <h3 align="center">You are logged in as <b><?php echo $_SESSION['username']; ?></b></h3>
                </div>
                <div class="modal-body" style="padding:40px 50px;">
                    <div align="center">
                        <a href="logout.php" class="btn btn-block btn-danger">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>




<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<!-- <script src="assets/js/docs.min.js"></script> -->
<script src="assets/js/search.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="assets/js/dataTables.min.js"></script>

<!-- FOR DataTable -->
<script>
    {
        $(document).ready(function()
        {
            $('#myTable').DataTable();
        });
    }
</script>

<!-- this function is for modal -->
<script>
    $(document).ready(function()
    {
        $("#myBtn").click(function()
        {
            $("#myModal").modal();
        });
    });
</script>

<script type="text/javascript">
    $(".remove").click(function(){
        var id = $(this).parents("tr").attr("id");


        if(confirm('Are you sure to remove this record ?'))
        {
            $.ajax({
               url: '/deletecompany.php',
               type: 'GET',
               data: {id: id},
               error: function() {
                  alert('Record removed successfully');
               },
               success: function(data) {
                    $("#"+id).remove();
                    alert("Record removed successfully");  
               }
            });
        }
    });


</script>
    
   

</html>
<?php

include ("last.php");

?>
