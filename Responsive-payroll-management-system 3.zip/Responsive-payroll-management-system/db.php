

<?php
//error_reporting(0);
ob_start();
session_start();
$siteName = "Cipet.in";

//DEFINE("BASE_URL","http://cipetbhopal.com/");

DEFINE("BASE_URL","Your Web Site Url");

/*
DEFINE ('DB_USER', 'msjahidprinters_payrollN');
DEFINE ('DB_PSWD', 'M59RZHM2BC2544');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'msjahidprinters_payrollN');
*/
DEFINE ('DB_USER', 'username');
DEFINE ('DB_PSWD', '');
DEFINE ('DB_HOST', 'hotname');
DEFINE ('DB_NAME', 'databasename');

date_default_timezone_set('Asia/Dhaka');
$conn =  new mysqli(DB_HOST,DB_USER,DB_PSWD,DB_NAME);
if($conn->connect_error)
    die("Failed to connect database ".$conn->connect_error );
