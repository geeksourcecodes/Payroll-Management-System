
<?php
include("first.php");
include("php/header.php");
?>
        <div id="page-wrapper">
            <div id="page-inner">
              <div class="row">
                  <div class="col-md-12">
                      
                      
              <style type="text/css">
                  .different-text-color { color: #191970; }
                   </style>                    
                  <marquee>  <h1 class="page-subhead-line"><p style="font-size:xx-large;"><span class="different-text-color" style="font-weight:bold;">Welcome To--Display @ <strong><?php echo ' '. $siteName ?></strong>@@@ Today is:
                  <i class="icon-calendar icon-large" ></i>


                  <?php
                  date_default_timezone_set("Asia/Dhaka");
                 echo  date(" l, F d, Y") . "<br>";

                  ?>
           </span>
           </p>
           </h1> 
        </marquee>
         

                  </div>
              </div>
                <!-- /. ROW  -->
                <?php
                include("main.php");
                ?>
                <!-- /. ROW  -->


            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec" style="margin-left:250px;">
        
M/S. jahid Printers & ADD | Developed By : <a href="https://web.facebook.com/anupamhayatbd" target="_blank">Md. Anupam Hayat</a>,
<a href="https://www.facebook.com/riyajulislam.abir" target="_blank">Md.Riyajul Islam (Abir)</a>
</div>

   <script src="js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="js/custom1.js"></script>



</body>
</html>
